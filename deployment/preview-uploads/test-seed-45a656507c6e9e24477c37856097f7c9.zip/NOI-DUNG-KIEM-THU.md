﻿# Văn bản pháp luật – bộ kiểm thử LMS

Tệp mẫu giả lập để kiểm tra tải học liệu, tên tệp và danh mục.
Không phải giáo trình hay văn bản pháp luật chính thức.

## Bài tập
Xác định vấn đề, liệt kê dữ kiện, tìm tài liệu được giao và trình bày lập luận.
